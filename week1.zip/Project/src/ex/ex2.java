package ex;

public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=0;
		int c[]= {1,2,3};
		try {
			
			try {
				
				int d=a/b;
				System.out.println(d);
			}
			catch(ArithmeticException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
			System.out.println(c[8]);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		System.out.println("Done");

	}

}

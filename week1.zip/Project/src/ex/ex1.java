package ex;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=0;
		int x[]= {1,2};
		try {
			int c=a/b;
			System.out.println(x[5]);
			
		}
		catch(ArithmeticException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	    catch(Exception e) {
	    	System.out.println(e.getMessage());
			e.printStackTrace();
	    	
	    }
		System.out.println("Done");

	}

}

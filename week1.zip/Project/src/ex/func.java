package ex;

public class func {
	

}

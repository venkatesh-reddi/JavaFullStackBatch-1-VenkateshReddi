package Jdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Scanner;

public class JdbcDemo {

	public static void main(String[] args) throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "Sys123");
		System.out.println("Connection SUCCESSFUL");
		Statement st=con.createStatement();
		/*
		PreparedStatement pst=con.prepareStatement("insert into plan values(?,?)");
		System.out.println("Enter 3 plan records, id and name");
		Scanner sc=new Scanner(System.in);
		for(int i=1;i<=3;i++) {
			pst.setInt(1, sc.nextInt());
			pst.setString(2,sc.next ());
			pst.execute();
			
			
		}
		*/
		ResultSet rs=st.executeQuery("select * from plan");
		ResultSetMetaData rsmd=rs.getMetaData();
		System.out.println(rsmd.getColumnCount());
		for(int i=1;i<=rsmd.getColumnCount();i++) {
			System.out.print(rsmd.getColumnName(i)+" ");
			
		}
		System.out.println();
		System.out.println("======");
		while(rs.next()) {
			System.out.println(rs.getString(1)+" "+rs.getString(2));
		}
		/*PreparedStatement pst=con.prepareStatement("update plan set name=? where pid=?");
		System.out.println("enter Id for which name to be updated");
		Scanner sc=new Scanner(System.in);
		int id=sc.nextInt();
		String newName=sc.next();
		pst.setString(1, newName);
		pst.setInt(2,id);
		pst.execute();
		System.out.println("Name updated"); */
		PreparedStatement pst1=con.prepareStatement("delete from plan where pid=?");
		System.out.println("Enter the ID for which the record needs to be deleted: ");
		Scanner sc=new Scanner(System.in);
		int id1=sc.nextInt();
		pst1.setInt(1, id1);
		pst1.execute();
		System.out.println("Deleted "+id1);
		
		
		
		
		
		

	}

}

package Jdb;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;
import java.util.Scanner;

public class JdbcDemo2 {

	public static void main(String[] args) throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "Sys123");
		System.out.println("Connection SUCCESSFUL");
		CallableStatement cst=con.prepareCall("{CALL square123(?,?)");
		System.out.println("Enter the number: ");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		cst.setInt(1, num);
		cst.registerOutParameter(2,Types.INTEGER);
		cst.execute();
		System.out.println("Result from db is:"+cst.getInt(2));

	}

}

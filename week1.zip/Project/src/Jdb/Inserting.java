package Jdb;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;

public class Inserting {

	public static void main(String[] args)throws ClassNotFoundException,SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "Sys123");
		System.out.println("Connection SUCCESSFUL");
		Statement st=con.createStatement();
		//st.executeUpdate("insert into plan values(1,'PLATINUM')");
		//st.executeUpdate("insert into plan values(2,'GOLD')");
		System.out.println("Done");
		
		ResultSet rs=st.executeQuery("select * from plan");
		while(rs.next()){
			System.out.println(rs.getString(1)+" "+rs.getString(2));
			
		}
		

	}

}

package com.verizon;

import java.util.Scanner;

public class InputMultiple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length and Breadth");
		int l=sc.nextInt();
		int b=sc.nextInt();
		if(l>0 && b>0) {
			int area=l*b;
			System.out.println("Area of the Rectagle:"+area);
		}
		else {
			System.out.println("Length and Breadth Can't be zero");
		}

	}
}

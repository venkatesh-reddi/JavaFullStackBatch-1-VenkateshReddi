package com.verizon.la;
class two{
	double f2c(double fahr) {
		return (fahr - 32) * 5 / 9;
		}
	public static void main(String args[]) {
		double fahrenheit = 62.5;
		two f=new two();
		
		double celsius = f.f2c(fahrenheit);
		System.out.println(fahrenheit + "F = "+ celsius + 'C');
		
		
	}

}
	



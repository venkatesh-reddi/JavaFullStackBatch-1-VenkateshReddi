package com.verizon.la;

import java.util.Scanner;

//Write a program that reads a number in feet, converts it to
//meters, and displays the result. One foot is 0.305 meters.
public class three {

	public static void main(String[] args) {
		System.out.println("Enter feet: ");
		Scanner sc=new Scanner(System.in);
		int feet=sc.nextInt();
		double meters = 0.305*feet;
		System.out.println(meters);
		
		
		

	}

}

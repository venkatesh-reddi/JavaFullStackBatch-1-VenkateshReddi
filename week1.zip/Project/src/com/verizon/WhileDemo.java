package com.verizon;

public class WhileDemo extends Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int x=1;
		for(int i=0;i<=10;i+=2) {
			System.out.println(i);
		}

		/*		while(x<=10) {
			x++;
			if(x==5) 
				continue;
			System.out.println(x);
			} */

	}

}

package com.verizon.collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;


public class ListDemo {

	public static void main(String[] args) {
		Set<Object> names=new HashSet<>();
		names.add("Varsha");
		names.add("Mydhili");
		System.out.println(names);
		Set<Integer> n=new TreeSet<>();
		n.add(4);
		n.add(2);
		n.add(10);
		System.out.println(n);

	}

}

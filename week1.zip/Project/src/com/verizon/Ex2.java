package com.verizon;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Ex2 {
	
		
	
	public static void main(String[] args) {
		FileReader fi1;//=new FileReader();
		try {
			 fi1=new FileReader("c:\\abc.txt");
		} 
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			try {
				//fi1.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("DOne");
		
	}
}

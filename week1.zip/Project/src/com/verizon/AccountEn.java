package com.verizon;

public class AccountEn {
	int acno;
	String name;
	double balance;
	AccountEn(){
		acno=999;
		name="ABC";
		balance=0;
	}
	public AccountEn(int acno, String name, double balance) {
		this.acno = acno;
		this.name = name;
		this.balance = balance;
	}

	void deposit(int amt) {
		balance+=amt;
		
	}
	double withdraw(int amt) {
		balance-=amt;
		return balance;
	}
	double getBalance() {
		return balance;
	}
	

}



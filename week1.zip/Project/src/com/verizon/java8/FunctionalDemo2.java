package com.verizon.java8;
@FunctionalInterface
interface Arith{
	int getSum(int a, int b);
}

public class FunctionalDemo2{
	public static void main(String args[]) {
		Arith arith=(a,b)-> a+b;
		System.out.println(arith.getSum(2,3));
		Arith arith1=(int a,int b)->{int c=a+b;return c;};
		System.out.println(arith1.getSum(4, 80));
		Arith arith3=(a,b)->(a*a)-(b*b);
		System.out.println(arith3.getSum(2,3));
		
}
	

}


package com.verizon.java8;
@FunctionalInterface
interface Arith1<T>{
	T op(T a, T b);
}

public class generic {

	public static void main(String[] args) {
		Arith1<Integer> arith=(a,b)->a+b;
		System.out.println(arith.op(2,3));
		Arith1<Double> arith2=(a,b)->(a*a)+(b*b);
		System.out.println(arith2.op(3.0,3.0));

	}

}

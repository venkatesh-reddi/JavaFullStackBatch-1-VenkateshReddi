package com.verizon.java8;

import java.util.StringJoiner;

public class StringJoin {

	public static void main(String[] args) {
		StringJoiner Names = new StringJoiner(",");
		Names.add("Rahul");
		Names.add("ABC");
		System.out.println(Names);
		System.out.println(Names.length());
		StringJoiner s1=new StringJoiner("-");
		s1.add("xyz");
		s1.add("Here");
		System.out.println(Names.merge(s1));

	}

}

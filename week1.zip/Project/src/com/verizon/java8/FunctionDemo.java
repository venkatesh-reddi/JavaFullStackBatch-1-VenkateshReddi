package com.verizon.java8;

public class FunctionDemo {
	int getSum(int a, int b) {
		return a+b;
	}

	public static void main(String[] args) {
		
		FunctionDemo f=new FunctionDemo();
		System.out.println(f.getSum(3,5));
		// TODO Auto-generated method stub

	}

}

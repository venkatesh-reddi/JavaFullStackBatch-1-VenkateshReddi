package com.verizon.java8;

import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class FunctionalDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer<Integer> consumer=(a)->System.out.println("Add:"+(a));
		consumer.accept(3);
		Consumer<Integer> consumer1=(b)->System.out.println(b+b);
		consumer1.accept(2);
		
		Supplier<Integer> s1=()->4+4;
		System.out.println(s1.get());
		Supplier<Integer> s2=()->new Random().nextInt(100);
		System.out.println(s2.get());
		
	    Predicate<Integer> p=(a)->a%2==0;
		System.out.println(p.test(8));
		
		Function<Integer,Integer> f=(a)->a*a;
		System.out.println(f.apply(5));
		
		Function<String,Integer> f1=(n)->Integer.parseInt(n);
		System.out.println(f1.apply("2")+8);
		
		
		
		
		
		
		
		
		
	}

}

package com.verizon;

public class E1 {

	public static void main(String[] args) throws DepositExceptions {
		// TODO Auto-generated method stubint 
		int amt=999;
		if(amt<1000)
			throw new DepositExceptions("No");
		else
			System.out.println("Thanks");
		

	}

}

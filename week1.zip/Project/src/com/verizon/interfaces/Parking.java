package com.verizon.interfaces;

public interface Parking {
	void getslot();
	

}

package com.verizon.interfaces;

public class VehicleLoan implements Loan,Surity {

	public void applyLoan(String name, double amount) {
		// TODO Auto-generated method stub
		
	}

	public void submitDocs() {
		// TODO Auto-generated method stub
		
	}

	public int getEmi() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void submitDocs2() {
		// TODO Auto-generated method stub
		
	}

}

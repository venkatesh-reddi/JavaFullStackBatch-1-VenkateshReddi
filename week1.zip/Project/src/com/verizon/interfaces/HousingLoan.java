package com.verizon.interfaces;

public class HousingLoan implements Loan,Surity {
	public void applyLoan(String name, double amount){
		System.out.println("Loan is applied by"+name+"of"+amount);
	}
	public void submitDocs() {
		System.out.println("Docs are submitted");
	}
	public int getEmi() {
		return 99342;
	}
	
	public void submitDocs2() {
		// TODO Auto-generated method stub
		
	}
	
	

}

package com.verizon.interfaces;

interface Loan {
	void applyLoan(String name,double amount);
	void submitDocs();
	int getEmi();

}

package com.verizon.interfaces;

public interface Surity {
	void submitDocs2();
	

}

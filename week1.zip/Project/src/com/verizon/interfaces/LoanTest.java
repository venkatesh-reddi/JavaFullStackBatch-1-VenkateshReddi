package com.verizon.interfaces;

public class LoanTest {

		public static void main(String[] args) {
			Loan l;
			HousingLoan h1=new HousingLoan();
			l=h1;
			//Loan l=new HousingLoan();
			//HousingLoan h=new HousingLoan();
			l.applyLoan("Ram",100000.00);
			l.submitDocs();
			System.out.println(l.getEmi());
			Surity s1=h1;
			s1.submitDocs2();
			VehicleLoan v1=new VehicleLoan();
			l=v1;
			l.applyLoan("Heera",300000.00);
			l.submitDocs();
			System.out.println(l.getEmi());
			s1=v1;
			s1.submitDocs2();
			
			
		

		}

	}




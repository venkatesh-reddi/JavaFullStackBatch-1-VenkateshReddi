package com.verizon;

import java.util.Scanner;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String vname="VeriZon";//Ways to create string ---String literal 
		//String vname1="VeriZon";
		System.out.println(vname);
		Scanner x=new Scanner(System.in);
		System.out.println("Enter name");
		String vname1=x.nextLine();
		
		
		System.out.println(vname.length());
		System.out.println(vname.charAt(2));
		System.out.println(vname.indexOf("V"));
		System.out.println(vname.toLowerCase());
		System.out.println(vname.compareTo(vname1));
		System.out.println(vname.equals(vname1));
		System.out.println(vname.replace("z", "Z"));
		System.out.println(vname==vname1);
		//String vname1=new String("....");// String object
		//Scanner sc=new Scanner(System.in);
		String comments=new String("Java is not bad");
		String Tokens[]=comments.split(" ");
		for(int i=0;i<Tokens.length;i++)
			System.out.println(Tokens[i]);
		StringBuffer sb=new StringBuffer("Java Technology");
		System.out.println(sb.insert(3,"eys"));
		
				
		
		
		
		
		
		
		
		

	}

}

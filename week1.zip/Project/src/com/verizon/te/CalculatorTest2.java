package com.verizon.te;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest2 {
	Calculator c;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("Test in BeforeAll");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("Object tore");
	}

	@BeforeEach
	void setUp() throws Exception {
		System.out.println("Testing each case method Started");
		c=new Calculator();
		
	}

	@AfterEach
	void tearDown() throws Exception {
		System.out.println("Object tore");
		c=null;
		
	}

	@Test
	void testSum() {
		assertEquals(5,c.sum(2, 3));
		//fail("Not yet implemented");
	}
	@Test
	void testdiff() {
		assertEquals(-1,c.diff(2, 3));
		//fail("Not yet implemented");
		
	}
	@Test
	void testmul() {
		assertEquals(6,c.mul(2, 3));
		//fail("Not yet implemented");
	}

}

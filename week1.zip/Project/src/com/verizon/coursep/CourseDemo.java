package com.verizon.coursep;

import java.util.List;

public class CourseDemo {

	public static void main(String[] args) {
		Course c1=new Course(40,"Python",2000.00);
		Course c2=new Course(20,"Java",3000.00);
		CourseService cs=new CourseServicesImpl();
		cs.addCourse(c1);
		cs.addCourse(c2);
		cs.deleteCourse(20);
		cs.updateCourse(40);
		//cs.deleteCourse(20);
		List<Course> returnedList=cs.listCourses();
		for(Course c:returnedList)
			System.out.println(c);

	}

}

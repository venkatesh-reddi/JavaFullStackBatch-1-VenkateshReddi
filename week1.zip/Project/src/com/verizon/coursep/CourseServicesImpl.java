package com.verizon.coursep;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CourseServicesImpl implements CourseService {
	List<Course> courselist=new ArrayList<>();

	@Override
	public String addCourse(Course c) {
		courselist.add(c);
		
		return "Course added successfully";
	}

	@Override
	public String deleteCourse(Integer cid) {
		Iterator i=courselist.iterator();
		while(i.hasNext()) {
			Course course=(Course)i.next();
			if(course.id==cid)
				i.remove();
		}
		return "Removed Successfully";
	}

	@Override
	public String updateCourse(Integer cid) {
		Iterator i=courselist.iterator();
		while(i.hasNext()) {
		Course course=(Course)i.next();
		if(course.id==cid)
			course.fee=course.fee+1000;
	}
	return "Updated Successfully";
	}

	@Override
	public List<Course> listCourses() {
		// TODO Auto-generated method stub
		return courselist;
	}

}

package com.verizon.poly;

public class Mride1 extends Mride {
	@Override
	void sq(int s) {
		System.out.println("Cube"+(s*s*s));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mride1 m=new Mride1();
		m.sq(4);

	}

}

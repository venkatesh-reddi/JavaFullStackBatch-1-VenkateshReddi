package com.verizon.poly;

public class Mload {
	void area(int s) {
		System.out.println("Square "+(s*s));
		
	}
	void area(int l,int b) {                         //Static polymorphism
		System.out.println("Rect "+(l*b));
	}
	void area(double r) {
		System.out.println("Circle "+(3.14*r*r));
	}

	public static void main(String[] args) {
		Mload m=new Mload();
		m.area(2);
		m.area(3,4);
		m.area(3.12);

	}

}

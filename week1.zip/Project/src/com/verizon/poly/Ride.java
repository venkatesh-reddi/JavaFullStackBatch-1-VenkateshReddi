package com.verizon.poly;

public class Ride {
	void sq(int s)
	{
		System.out.println("Area: "+(s*s));
	}
}

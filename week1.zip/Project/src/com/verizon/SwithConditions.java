package com.verizon;

import java.util.Scanner;

public class SwithConditions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Choose Operation: + - * / and 2 numbers");
		Scanner sc=new Scanner(System.in);
		char ch=sc.next().charAt(0);
		int a=sc.nextInt();
		int b=sc.nextInt();
		switch(ch){
		    case '+':{System.out.println("Sum: "+(a+b));
		    break;
		             }
		    case '-':{System.out.println("Sub: "+(a-b));
		    break;
			         }
		    case '*':{System.out.println("Mul: "+(a*b));
		    break;
			         }
		    case '/':{System.out.println("Div: "+(a/b));
		    break;
			         }
		    default: System.out.println("Enter the correct Operator");
		    
		}
		

	}

}

package com.verizon;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
		int a[] = { 2, 4, 6, 8, 10 };
		for (int i = 0; i < a.length; i++)
			// System.out.println(a[i]);
			sum += a[i];
		System.out.println("Sum of elements of aray:" + sum);
		int b[] = new int[5];
		System.arraycopy(a, 0, b, 1, 3);
		for (int i = 0; i < b.length; i++)
			System.out.print(b[i] + " ");

	}

}

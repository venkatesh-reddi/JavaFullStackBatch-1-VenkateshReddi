package com.verizon;

import java.util.Scanner;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World");
		System.out.println("ENter: ");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Scanner t=new Scanner(System.in);
		System.out.println("ENter: ");
		String name=t.nextLine();
		System.out.println(n);
		System.out.println(name);
				
		
		

	}

}

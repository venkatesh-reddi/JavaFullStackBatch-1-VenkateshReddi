package com.verizon;

public class SavingsAccount extends AccountEn {
	String proof;
	String bname;
	
	void show() {
		deposit(3000);
		System.out.println(getBalance());
		System.out.println(acno+" "+balance);  //parent attributes
		
	}
	public static void main(String args[]) {
		SavingsAccount sa=new SavingsAccount();
		AccountEn a=new AccountEn();
		sa.show();
		System.out.println(a.getBalance());
				
		
	}
	
	
	

}

package com.verizon;

import java.util.Scanner;

public class Trial {

	public static void main(String[] args) {
		int i;
		int b[]= {1,2,3};
		for(i=0;i<b.length;i++){
			System.out.print(b[i]);
		}
		System.out.println("\nEnter the size of array: ");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a[]=new int[n];
		for(i=0;i<n;i++) {
			System.out.println("Enter "+i+" th element");
			a[i]=sc.nextInt();
		}
		for(i=0;i<n;i++) {
			System.out.println("The"+i+" th element is: "+a[i]);
		}
		int v=10;
		int t=0;
		
		try {
			int di=v/t;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
				
				
	

	}

}

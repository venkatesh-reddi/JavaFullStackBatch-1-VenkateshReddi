package com.verizon;

public class HousingLoan extends Loan {
	void applyLoan(String name, double amount){
		System.out.println("Loan is applied by"+name+"of"+amount);
	}
	void submitDocs() {
		System.out.println("Docs are submitted");
	}
	int getEmi() {
		return 99342;
	}
	

}

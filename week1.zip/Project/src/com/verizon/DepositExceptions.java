package com.verizon;

public class DepositExceptions extends Exception{
	DepositExceptions(String msg){
		super(msg);
	}

}

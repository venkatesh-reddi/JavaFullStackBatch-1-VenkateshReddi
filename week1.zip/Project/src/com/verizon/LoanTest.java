package com.verizon;

public class LoanTest {

	public static void main(String[] args) {
		

		Loan l=new HousingLoan();
		
		//HousingLoan h=new HousingLoan();
		l.applyLoan("Ram",100000.00);
		l.submitDocs();
		System.out.println(l.getEmi());
		l=new VehicleLoan();
		l.applyLoan("Heera",300000.00);
		l.submitDocs();
		System.out.println(l.getEmi());
		
		
	

	}

}

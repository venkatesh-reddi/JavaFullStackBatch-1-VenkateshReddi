package com.verizon;

public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=0;
		int c[]= {3,4,5};
		
		try { try {
			System.out.println(c[5]);
			}
		    catch(ArrayIndexOutOfBoundsException e) {
		    	e.printStackTrace();
		    	
		    }
		    int d=a/b;
			System.out.println(d);
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			
		}
		

	}

}

package com.verizon;

public class AccountEnDemo {

	public static void main(String[] args) {
	
		AccountEn accounten=new AccountEn(); //Constructor values as default
		//accounten.acno=123;
		//accounten.name="XYZ";   //Assigning values while creating object
		//accounten.balance=1000;
		System.out.println(accounten);
		accounten.deposit(300);
		System.out.println(accounten.acno+" "+accounten.name+"  "+accounten.balance);
		//parameterized constructor
		AccountEn accounten1=new AccountEn(111,"Raam",2567);
		System.out.println(accounten1);
		System.out.println(accounten1.acno+" "+accounten1.name+"  "+accounten1.balance);
				
		

	}

}

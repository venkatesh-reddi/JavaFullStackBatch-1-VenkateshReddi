package com.verizon;
import java.util.Scanner;

public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("This is a Sample!");
		//System.out.println(args[0]);
		//System.out.println(args[1]);
		Scanner n=new Scanner(System.in);
		System.out.println("Enter your name");
		String name=n.nextLine();
		System.out.println("My name is: "+name);

	}

}



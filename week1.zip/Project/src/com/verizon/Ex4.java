package com.verizon;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Ex4 {
	public static void main(String[] args) {
		try(FileReader f=new FileReader("c:/abc.txt");){
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Done");
				

}
}
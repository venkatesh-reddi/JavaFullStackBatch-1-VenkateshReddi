package com.verizon;

public class VehicleLoan extends Loan {

	void applyLoan(String name, double amount) {
		System.out.println("Vehicle loan applied by"+name+" of"+amount);
		
		// TODO Auto-generated method stub
		
	}

	int getEmi() {
		// TODO Auto-generated method stub
		return 8888;
	}

	void submitDocs() {
		// TODO Auto-generated method stub
		System.out.println("Documents are submitted");
		
	}

}

package p3;

public class Training {
	public static void main(String[] args) {
		System.out.println(args[0]);
		System.out.println(args[1]);

	}

}

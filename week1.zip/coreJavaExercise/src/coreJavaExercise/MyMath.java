package coreJavaExercise;

public class MyMath {

}

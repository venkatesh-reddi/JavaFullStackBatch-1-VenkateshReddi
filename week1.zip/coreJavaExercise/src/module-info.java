/**
 * 
 */
/**
 * 
 */
module coreJavaExercise {
}
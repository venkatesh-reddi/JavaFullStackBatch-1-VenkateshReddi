/**
 * 
 */
/**
 * 
 */
module javabasics {
}
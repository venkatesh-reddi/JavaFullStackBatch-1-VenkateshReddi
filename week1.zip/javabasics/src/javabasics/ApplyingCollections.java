package javabasics;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ApplyingCollections {

	public static void main(String[] args) {
       Developer developer = new Developer("ManiDeepika", "Java, HTML");
		
		ArrayList<Developer> listOfDevelopers = new ArrayList<>();
		
		listOfDevelopers.add(developer);
		listOfDevelopers.add(new Developer("Dhruv", "Java, CSS, JS"));
		listOfDevelopers.add(new Developer("Pranav", "C, C++"));
		

		
		System.out.println("Currently we have the following developers registered:");
		for(Developer theDeveloper : listOfDevelopers) { 
			System.out.println(theDeveloper.getName() + " with skills : " + theDeveloper.getSkills());
		}
		

		
		
		System.out.println("After sorting, list:");
		for(Developer theDeveloper : listOfDevelopers) { 
			System.out.println(theDeveloper.getName());
		}
	}


}
class Developer{
	private String name;
	private String skills;
	public Developer(String name, String skills) {
		super();
		this.name = name;
		this.skills = skills;
	}
	
	public Developer() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	@Override
	public String toString() {
		return "Hi there I am a Developer [name=" + name + ", skills=" + skills + "]";
	}


class SortDevelopersByName implements Comparator<Developer>{

	@Override
	public int compare(Developer firstDeveloper, Developer secondDeveloper) {
		return firstDeveloper.getName().compareTo(secondDeveloper.getName());
	}
	
}

class SortDevelopersBySkills implements Comparator<Developer>{

	@Override
	public int compare(Developer firstDeveloper, Developer secondDeveloper) {
		return firstDeveloper.getSkills().compareTo(secondDeveloper.getSkills());
	}
	
}



package javabasics;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class EmployeeDetails {

	public static void main(String[] args) {
		int n;
		String name;
		int age;
		String country;
		System.out.println("enter 1 to add persons details");
		System.out.println("enter 2 to view the details");
		System.out.println("enter 3 to search by name");
		System.out.println("enter 4 to sort by first name, last name, age, country");
		System.out.println("now enter a number between 1 to 4");
		Scanner sc = new Scanner(System.in);
		n=sc.nextInt();
		if(n==1) {
			System.out.println("Enter Name");
			System.out.println("Enter Age");
			System.out.println("Enter Country");
		 }
		if(n==2) {
			Scanner s = new Scanner(System.in);
			name=s.next();
			age=s.nextInt();
			country=s.next();
		}
		
		
		
		
		
		
		
		
		
	}

}

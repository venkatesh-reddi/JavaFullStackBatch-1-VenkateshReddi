package javabasics;
import java.util.ArrayList;
import java.util.Collections;

public class CollectionsExample {

	public static void main(String[] args) {
		Employee employee = new Employee("harini","java");
		ArrayList<Employee> listOfEmployees = new ArrayList<>();
		listOfEmployees.add(employee);
		listOfEmployees.add(new Employee("srinidhi","java"));
		listOfEmployees.add(new Employee("harshitha","java"));
		System.out.println("currently we have the following employees registered");
		for(Employee theEmployee: listOfEmployees) {
			System.out.println(theEmployee.getName()+"with skills");
		}
		
		}
	
}
class Employee implements Comparable <Employee>{
	private String name;
	private String skills;
	public Employee(String name, String skills) {
		super();
		this.name=name;
		this.skills=skills;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}

}



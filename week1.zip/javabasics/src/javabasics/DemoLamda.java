package javabasics;

public class DemoLamda {

	public static void main(String[] args) {
		Employee ref= ()->{
		   System.out.println("details are displayed");
		};
ref.details();
Calculate add = (n1,n2)->{
	System.out.println("the sum is "  +(n1+n2));
};
add.addTwoNumbers(2,5);
	}
	
	

@FunctionalInterface
interface Employee{
	void details();
	
}
	
}
@FunctionalInterface
interface Calculate{
	void addTwoNumbers(int n1,int n2); 
	
}

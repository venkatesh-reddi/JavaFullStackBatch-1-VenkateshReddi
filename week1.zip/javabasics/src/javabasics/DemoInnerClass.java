package javabasics;

public class DemoInnerClass {

}

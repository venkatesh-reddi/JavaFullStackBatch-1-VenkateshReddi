package javabasics;
import java.util.ArrayList;

public class ArrayList1 {

	

	public static void main(String[] args) {
		ArrayList<String> Names = new ArrayList<String>();
		Names.add("Java");
		Names.add("python");
		Names.add("C");
		Names.add("C++");
		System.out.println("the languages are:");
		
		Names.forEach(System.out::println);
		Names.add("DBMS");
		Names.forEach(System.out::println);
		Names.remove(1);
		System.out.println("the languages are:");
		Names.forEach(System.out::println);
		
		System.out.println(Names.indexOf("DBMS"));
		System.out.println(Names.size());
		
		
	}

}

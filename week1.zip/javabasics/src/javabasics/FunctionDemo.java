package javabasics;
import java.util.function.Function;


public class FunctionDemo {

	public static void main(String[] args) {
		
	}

}
class DemoFunction {

	public static void main(String[] args) {
		
		int multipliedValue = multiplyFunction.apply(56);
		System.out.println(multipliedValue);
	}
	
	static Function<Integer, Integer> multiplyFunction = 
			value -> value *= 10;

}


package javabasics;

public class BasicJava {

	public static void main(String[] args) {
		Student s1 = new Student();
		s1.setRollno(0);
		s1.setName("harini");
		s1.setMarks(80);
		System.out.println(s1);
		Student s2 = new Student();
		s2.setRollno(50);
		s2.setName("kothagadi");
		s2.setMarks(85);
		System.out.println(s2);	
	}

	

	
}
  class Student{
	  public Student(int rollno, String name, int marks) {
		  
	  }
	  
	private int rollno;
	private String name;
	private int marks;
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
  }

	
  
   
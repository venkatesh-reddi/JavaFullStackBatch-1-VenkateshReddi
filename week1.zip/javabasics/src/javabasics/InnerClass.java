package javabasics;

public class InnerClass {

	public static void main(String[] args) {
		Employee employee = new Employee() {
			@Override
			public void details() {
				System.out.println("details are displayed");
				
				
				
			};
		};
		employee.details();

	}

}
interface Employee{
	void details();
}
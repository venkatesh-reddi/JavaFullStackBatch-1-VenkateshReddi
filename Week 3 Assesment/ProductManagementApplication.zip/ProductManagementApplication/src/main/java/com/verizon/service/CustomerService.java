package com.verizon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.verizon.dao.CustomerDao;
import com.verizon.model.Customer;
import jakarta.transaction.Transactional;
@Service
@Transactional
public class CustomerService {
	@Autowired
	CustomerDao customerDao;
	public Customer addCustomer(Customer customer) {
	
		return customerDao.save(customer);
	}
	public List<Customer> getAllCustomers() {
		//
		return customerDao.findAll();
	}
	public Customer updateCustomer(Integer cid, String cname, String email) {
		Customer c = customerDao.findByCid(cid);
		c.setCid(cid);
		c.setCname(cname);
		c.setEmail(email);
		return customerDao.save(c);
	}
	public void deleteCustomer(Integer cid) {
		customerDao.deleteById(cid);
		}
	}

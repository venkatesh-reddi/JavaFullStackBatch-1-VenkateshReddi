package com.overalt.exception.plan;

public class InvalidPlanDataException extends RuntimeException {
    public InvalidPlanDataException(String message) {
        super(message);
    }
}

package com.overalt.exception.friendorfamily;

public class InvalidFriendOrFamilyDataException extends RuntimeException{
    public InvalidFriendOrFamilyDataException(String message) {
        super(message);
    }
}

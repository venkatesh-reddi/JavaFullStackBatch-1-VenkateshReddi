package com.overalt.exception.calldetails;

public class InvalidCallDetailsException extends RuntimeException{
    public InvalidCallDetailsException(String message) {
        super(message);
    }
}

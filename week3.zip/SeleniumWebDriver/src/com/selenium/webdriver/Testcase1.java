package com.selenium.webdriver;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;

public class Testcase1 {
	
	WebDriver driver;

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	public void verifyTitleTest() {
		//fail("Not yet implemented");
		driver = new ChromeDriver();
		driver.get("https://www.geeksforgeeks.org/courses/gate-ds-ai-self-paced?source=google&medium=cpc&device=c&keyword=geeksforgeeks%20gate%20course&matchtype=b&campaignid=19710694532&adgroup=164787828848&gad_source=1&gclid=EAIaIQobChMIgOqtl_-HiAMVczjUAR2TBAW2EAAYASAAEgIGLPD_BwE");
		Assert.assertEquals(driver.getTitle(), "GATE Data Science and Artificial Intelligence 2025");
		driver.quit();
	}

}

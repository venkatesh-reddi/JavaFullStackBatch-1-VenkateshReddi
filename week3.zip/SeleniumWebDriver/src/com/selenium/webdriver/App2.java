package com.selenium.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class App2 {
	

	public static void main(String[] args) {
		WebDriver driver;
		driver =new FirefoxDriver();
		try {
			driver.get("https://www.geeksforgeeks.org/");
			String pageTitle=driver.getTitle();
			System.out.println("Page Title is: "+pageTitle);
			//driver.manage().window().maximize();
			//driver.manage().deleteAllCookies();
			String tagname=driver.findElement(By.id("__NEXT_DATA__")).getTagName();
			System.out.println("Tagname : "+tagname);
			
		
		}
		finally {
			driver.quit();
		}
		
		

	}

}

package com.verizon.mavenfirstproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
@Component("Name")
public class DetailsOfStudent implements Student {
	@Autowired
	@Qualifier("name")
	private Name name;

	@Override
	public void show() {
		System.out.println("the student name is..");
		System.out.println(name);
		
	}
	public DetailsOfStudent(){
		
	}
	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "DetailsOfStudent [name=" + name + ", getName()=" + getName() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
	

}

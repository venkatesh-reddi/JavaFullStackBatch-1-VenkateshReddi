package com.verizon.mavenfirstproject;

public interface Cricketer {
	void play();

}

package com.verizon.mavenfirstproject;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {

    	

    	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("NewFile.xml");
    	

    	
    	DetailsOfStudent detailsOfStudent= context.getBean("name",DetailsOfStudent.class);
    	detailsOfStudent.show();
    	

 
 
    }
}

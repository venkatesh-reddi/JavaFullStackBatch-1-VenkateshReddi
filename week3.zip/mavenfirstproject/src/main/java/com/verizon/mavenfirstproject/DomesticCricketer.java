package com.verizon.mavenfirstproject;

public class DomesticCricketer implements Cricketer {
	private Address address;

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public void play() {
		System.out.println("Hi I am still playing domestic, my address details : ");
		System.out.println(address);

	}


}

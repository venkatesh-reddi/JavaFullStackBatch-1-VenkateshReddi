package com.verizon.mavenfirstproject;

public class Name {
	private String name;


public Name(String name) {
	this.name= name;
	
}


@Override
public String toString() {
	return "Name [name=" + name + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
			+ super.toString() + "]";
}
public static void main(String[] args) {
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}
}

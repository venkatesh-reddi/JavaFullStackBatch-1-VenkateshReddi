package com.verizon.mavenfirstproject;

public interface Student {
	void show();

}

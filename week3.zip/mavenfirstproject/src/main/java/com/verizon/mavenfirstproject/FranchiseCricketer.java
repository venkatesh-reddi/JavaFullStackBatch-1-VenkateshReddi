package com.verizon.mavenfirstproject;
import java.util.List;

public class FranchiseCricketer implements Cricketer {

	private String name;
	private String franchise;


	private List<Contact> listOfContacts;


	public void setListOfContacts(List<Contact> listOfContacts) {
		this.listOfContacts = listOfContacts;
	}

	public FranchiseCricketer() {
			}

	public FranchiseCricketer(String name, String franchise, List<Contact> listContacts) {

		this.name = name;
		this.franchise = franchise;
		this.listOfContacts = listContacts;
	}

	public void setName(String name) {

		this.name = name;
	}

	public void setFranchise(String franchise) {
		this.franchise = franchise;

	}

	@Override
	public void play() {
		System.out.println("Hi there I am " + this.name + " and I play for " + this.franchise);
		System.out.println("And I can be reached on : ");
		listOfContacts.forEach(System.out::println);
	


	}
}

package com.verizon.mavenfirstproject;

public interface springClass {
	void show();

}


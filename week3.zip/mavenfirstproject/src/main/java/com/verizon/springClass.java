package com.verizon;

public interface springClass {
	void show();

}

package com.verizon;

public class Sum {
	
	public int Add(int a,int b) {
		return a+b;
		
	}

}

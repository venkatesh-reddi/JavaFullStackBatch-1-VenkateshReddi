package com.verizon.ConsumerAppl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerApplApplicationTests {

	@Test
	void contextLoads() {
	}

}

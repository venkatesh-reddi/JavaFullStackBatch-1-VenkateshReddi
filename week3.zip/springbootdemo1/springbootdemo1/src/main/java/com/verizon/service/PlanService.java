package com.verizon.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.verizon.dao.PlanDao;
import com.verizon.model.Plan;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class PlanService {
	@Autowired
	PlanDao planDao;
	public String addPlan(Plan plan) {
		planDao.save(plan);
		return "Added";
		
		
	}
	
	

}

package com.verizon.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.model.Plan;

@RestController
public class PlanController {
	
	@GetMapping("/plan")
	public String getPlanDetails() {
		return "Plan1 deltails:45 days";
	}
	
	@PostMapping("/plan")
	public Plan getPlanDetails(@RequestBody Plan plan) {
		return plan;
		
	}
	@PutMapping("/plan")
	public String updatePlanDetails() {
		return "Plan Updated successfully";
	}
	@DeleteMapping
	public String deletePlanDetails() {
		return "Plan is deleted";
	}
	

}
